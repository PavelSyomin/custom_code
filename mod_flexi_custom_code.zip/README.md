# Flexi Custom Code

Flexi Custom Code module for Joomla. It was originally created by AppsNity, but they dropped the support, and the extension was removed from the Joomla extensions directory, and the developer's website was down. Here I am trying to continue the support of this extension. Main TODOs are to add support for Joomla 4 and PHP 8, to improve codestyle and to re-publish the extension if Joomla extensions directory.

## Authors

* RBO Team > Project::: RumahBelanja.com & AppsNity.com (v. 1.0—1.4).
* Pavel Syomin (v. 2.0).

## Main Features

* Support for PHP, HTML, JAVASCRIPT and CSS codes.
* Possible to set the target of this module.
* Easy and flexible.
